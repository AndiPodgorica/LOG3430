import unittest
from temperature_mtl import temperature_mtl

class temperature_mtlTEst(unittest.TestCase):
    def setUp(self):
    self.temperature = temperature_mtl()
    
    def test_milieu_entre_1986(self):
    annee = 1986
    temperature = self.temperature.get_temp_pour_annee(self,annee)
    self.assertEqual(37.5, temperature)